<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8"><link rel="stylesheet" href="<?php echo base_url();?>assets/css/custom.css" media="all">
<title> <?php foreach ($order_sheet as $row) { }?></title>
<link rel="shortcut icon" href="http://sim.tecdiary.my/themes/default/assets/img/favicon.ico">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="http://sim.tecdiary.my/themes/default/assets/style/bootstrap2.css" rel="stylesheet">
<link href="http://sim.tecdiary.my/themes/default/assets/style/style.css" rel="stylesheet">
<link href="http://sim.tecdiary.my/themes/default/assets/style/rwd-table.css" rel="stylesheet">
<script type="text/javascript" src="http://sim.tecdiary.my/themes/default/assets/js/jquery.js"></script>
<link rel="stylesheet" type="text/css" href="http://cdn.webrupee.com/font">
 <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style type="text/css">
html, body { height: 100%; padding:0; margin: 0; }
#wrap { padding: 20px; }
td, th { padding: 3px 6px; }
.word_text { text-transform: capitalize; }
@media print {
    .page-break { height: 40px; }
    .page-break { page-break-before: always; }
}
p{
    margin: 0 0 5px;
}
</style>
    <style>
#preloader  {
     position: absolute;
     top: 0;
     left: 0;
     right: 0;
     bottom: 0;
     background-color: #fefefe;
     z-index: 99;
    height: 100%;
 }
#status  {
     width: 200px;
     height: 200px;
     position: absolute;
     left: 50%;
     top: 50%;
     background-image: url(http://www.finacbooks.com/assets/img/ajax-loader.gif);
     background-repeat: no-repeat;
     background-position: center;
    margin: -100px 0 0 -100px;
 }
</style>


</head>

<body>
<?php echo 'hello'; ?>
    
    
    

</body>

</html>